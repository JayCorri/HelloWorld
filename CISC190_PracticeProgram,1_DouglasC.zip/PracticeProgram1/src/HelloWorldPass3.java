	/*
	 ************************
	 * CISC 190	2/1/17		*
	 * Douglas Corrigan		*
	 * Practice Assignment 1*
	 * Part 1c				*
	 * Due 2/3/17			*
	 ************************
	 */
	
	public class HelloWorldPass3 {

	/** @param args **/
	public static void main(String[] args) {
		int i;
		int count;
		int value1 = 0;
		String name;
		String firstName, lastName;
		name = "Snoopy";
		firstName = "Dr. Evil";
		lastName = "Mini Me";
		System.out.println("Hello World!");
		System.out.println("My name is "+ firstName + " and " + lastName+"!");
		//System.out.println("This is a Java Programming course.")	
		
		for(i=0; i<=4; i++) {
			System.out.print("Pass "+ i);		
			System.out.println(" = " + value1);
			++value1;
		}
	}
}