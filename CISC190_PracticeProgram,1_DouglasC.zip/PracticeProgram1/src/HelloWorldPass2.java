	/*
	 ************************
	 * CISC 190	2/1/17		*
	 * Douglas Corrigan		*
	 * Practice Assignment 1*
	 * Part 1b				*
	 * Due 2/3/17			*
	 ************************
	 */
	
	import java.text.DecimalFormat;
	//used import java.text.DecimalFormat to get hundreths decimal formatting
	
	public class HelloWorldPass2 {

	/** @param args **/
	public static void main(String[] args) {
		int i;
		int count;

		DecimalFormat value1 = new DecimalFormat("0.00");
		//decimal format procedure
		int value2 = 0;
		String name;
		String firstName, lastName;
		name = "Snoopy";
		firstName = "Dr. Evil";
		lastName = "Mini Me";
		System.out.println("Hello World!");
		System.out.println("My name is "+ firstName+"!");
		//System.out.println("This is a Java Programming course.")	
		
		for(i=0; i<=3; i++) {
			System.out.print("Pass "+ i);		
			System.out.println(" = " +value1.format(value2));
			++value2;
			//used value1.format(value2) because value2 held integer value1 held decimal format
		}
	}
}